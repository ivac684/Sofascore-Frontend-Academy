import GetPokemons from "./components/GetPokemons";

function App() {
  return (
    <div className="App">
      <GetPokemons />
    </div>
  );
}

export default App;